export default {
    FirebaseConfig: {
      apiKey: "AIzaSyBJXKWC8LQt5SamVcrzd74IM43O_7Vp0a8",
      authDomain: "react-test-79a3b.firebaseapp.com",
      databaseURL: "https://react-test-79a3b.firebaseio.com",
      projectId: "react-test-79a3b",
      storageBucket: "react-test-79a3b.appspot.com",
      messagingSenderId: "111166801374"
    },
}
